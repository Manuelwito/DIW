Realiza una presentación en la que muestres la evolución de tu web.
Indica las distintas opciones CSS que has ido utilizando desde los primeros diseños (divs con block-inline/float) hasta la versión con Flex/Grid.

Maquetación con block-inline
Maquetación con float
Media queries
Dark mode
Maquetación con Flex
Maquetación con Grid
Adjunta capturas de pantalla de la web y de las partes relevantes del código.